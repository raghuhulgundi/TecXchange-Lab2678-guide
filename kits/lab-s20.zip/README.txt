=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s20
=====================================================================
Everything you create carries s20. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s20-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s20-application.txt               topology: billing + webserver on s20-computer1000
  s20-application2.txt              topology: notifications + email on s20-computer1001
  s20-topology-events-network.json  3 events: computer, router, firewall
  s20-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s20-topology-events-app.json      3 events: computer, billing, webserver
  s20-temporal-events.json          4 events: s20-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student20     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s20
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s20

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s20
  Observer job Unique IDs ......... s20-infrastructure
                                    s20-application
                                    s20-application2
  Merge rule name ................. s20-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s20-infrastructure.txt
                                    FILE.OBSERVER:s20-application.txt
  Exact template name ............. s20-router1        seed: s20-router1
  Dynamic template name ........... s20-AppServers     seed: s20-computer1000
  Dynamic template seed tag ....... LAB-s20
  Application name ................ s20-Order Capture Backend
  Application tag ................. s20-orderBackend
  Scope policy name ............... s20 - Group by Location-Application
  Temporal policies (search) ...... [s20]   (2 policies, created by the instructor's training)
  Scope policy application value .. s20-NetCash
  Optional tag template ........... s20-tag-template  group: s20-tag-group  tag: LAB-s20
  Optional token template ......... s20-token-template  provider: FILE.OBSERVER:s20-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s20-router1, APPSERVER-s20-computer1000, APPSERVER-s20-computer1001
  Temporal: 2 groups for s20-myapp (newsletter pair; front-end + synthetic test)
  (optional) s20-tag-group, s20-Intel, s20-AMD

YOUR EVENT DAY (UTC): 2025-05-24   (unique to you, so your alerts never mix with others)
