=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s18
=====================================================================
Everything you create carries s18. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s18-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s18-application.txt               topology: billing + webserver on s18-computer1000
  s18-application2.txt              topology: notifications + email on s18-computer1001
  s18-topology-events-network.json  3 events: computer, router, firewall
  s18-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s18-topology-events-app.json      3 events: computer, billing, webserver
  s18-temporal-events.json          4 events: s18-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student18     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s18
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s18

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s18
  Observer job Unique IDs ......... s18-infrastructure
                                    s18-application
                                    s18-application2
  Merge rule name ................. s18-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s18-infrastructure.txt
                                    FILE.OBSERVER:s18-application.txt
  Exact template name ............. s18-router1        seed: s18-router1
  Dynamic template name ........... s18-AppServers     seed: s18-computer1000
  Dynamic template seed tag ....... LAB-s18
  Application name ................ s18-Order Capture Backend
  Application tag ................. s18-orderBackend
  Scope policy name ............... s18 - Group by Location-Application
  Temporal policies (search) ...... [s18]   (2 policies, created by the instructor's training)
  Scope policy application value .. s18-NetCash
  Optional tag template ........... s18-tag-template  group: s18-tag-group  tag: LAB-s18
  Optional token template ......... s18-token-template  provider: FILE.OBSERVER:s18-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s18-router1, APPSERVER-s18-computer1000, APPSERVER-s18-computer1001
  Temporal: 2 groups for s18-myapp (newsletter pair; front-end + synthetic test)
  (optional) s18-tag-group, s18-Intel, s18-AMD

YOUR EVENT DAY (UTC): 2025-05-22   (unique to you, so your alerts never mix with others)
