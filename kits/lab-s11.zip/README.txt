=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s11
=====================================================================
Everything you create carries s11. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s11-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s11-application.txt               topology: billing + webserver on s11-computer1000
  s11-application2.txt              topology: notifications + email on s11-computer1001
  s11-topology-events-network.json  3 events: computer, router, firewall
  s11-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s11-topology-events-app.json      3 events: computer, billing, webserver
  s11-temporal-events.json          4 events: s11-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student11     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s11
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s11

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s11
  Observer job Unique IDs ......... s11-infrastructure
                                    s11-application
                                    s11-application2
  Merge rule name ................. s11-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s11-infrastructure.txt
                                    FILE.OBSERVER:s11-application.txt
  Exact template name ............. s11-router1        seed: s11-router1
  Dynamic template name ........... s11-AppServers     seed: s11-computer1000
  Dynamic template seed tag ....... LAB-s11
  Application name ................ s11-Order Capture Backend
  Application tag ................. s11-orderBackend
  Scope policy name ............... s11 - Group by Location-Application
  Temporal policies (search) ...... [s11]   (2 policies, created by the instructor's training)
  Scope policy application value .. s11-NetCash
  Optional tag template ........... s11-tag-template  group: s11-tag-group  tag: LAB-s11
  Optional token template ......... s11-token-template  provider: FILE.OBSERVER:s11-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s11-router1, APPSERVER-s11-computer1000, APPSERVER-s11-computer1001
  Temporal: 2 groups for s11-myapp (newsletter pair; front-end + synthetic test)
  (optional) s11-tag-group, s11-Intel, s11-AMD

YOUR EVENT DAY (UTC): 2025-05-15   (unique to you, so your alerts never mix with others)
