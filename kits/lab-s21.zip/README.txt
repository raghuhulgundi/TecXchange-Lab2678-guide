=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s21
=====================================================================
Everything you create carries s21. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s21-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s21-application.txt               topology: billing + webserver on s21-computer1000
  s21-application2.txt              topology: notifications + email on s21-computer1001
  s21-topology-events-network.json  3 events: computer, router, firewall
  s21-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s21-topology-events-app.json      3 events: computer, billing, webserver
  s21-temporal-events.json          4 events: s21-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student21     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s21
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s21

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s21
  Observer job Unique IDs ......... s21-infrastructure
                                    s21-application
                                    s21-application2
  Merge rule name ................. s21-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s21-infrastructure.txt
                                    FILE.OBSERVER:s21-application.txt
  Exact template name ............. s21-router1        seed: s21-router1
  Dynamic template name ........... s21-AppServers     seed: s21-computer1000
  Dynamic template seed tag ....... LAB-s21
  Application name ................ s21-Order Capture Backend
  Application tag ................. s21-orderBackend
  Scope policy name ............... s21 - Group by Location-Application
  Temporal policies (search) ...... [s21]   (2 policies, created by the instructor's training)
  Scope policy application value .. s21-NetCash
  Optional tag template ........... s21-tag-template  group: s21-tag-group  tag: LAB-s21
  Optional token template ......... s21-token-template  provider: FILE.OBSERVER:s21-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s21-router1, APPSERVER-s21-computer1000, APPSERVER-s21-computer1001
  Temporal: 2 groups for s21-myapp (newsletter pair; front-end + synthetic test)
  (optional) s21-tag-group, s21-Intel, s21-AMD

YOUR EVENT DAY (UTC): 2025-05-25   (unique to you, so your alerts never mix with others)
