=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s07
=====================================================================
Everything you create carries s07. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s07-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s07-application.txt               topology: billing + webserver on s07-computer1000
  s07-application2.txt              topology: notifications + email on s07-computer1001
  s07-topology-events-network.json  3 events: computer, router, firewall
  s07-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s07-topology-events-app.json      3 events: computer, billing, webserver
  s07-temporal-events.json          4 events: s07-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student07     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s07
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s07

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s07
  Observer job Unique IDs ......... s07-infrastructure
                                    s07-application
                                    s07-application2
  Merge rule name ................. s07-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s07-infrastructure.txt
                                    FILE.OBSERVER:s07-application.txt
  Exact template name ............. s07-router1        seed: s07-router1
  Dynamic template name ........... s07-AppServers     seed: s07-computer1000
  Dynamic template seed tag ....... LAB-s07
  Application name ................ s07-Order Capture Backend
  Application tag ................. s07-orderBackend
  Scope policy name ............... s07 - Group by Location-Application
  Temporal policies (search) ...... [s07]   (2 policies, created by the instructor's training)
  Scope policy application value .. s07-NetCash
  Optional tag template ........... s07-tag-template  group: s07-tag-group  tag: LAB-s07
  Optional token template ......... s07-token-template  provider: FILE.OBSERVER:s07-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s07-router1, APPSERVER-s07-computer1000, APPSERVER-s07-computer1001
  Temporal: 2 groups for s07-myapp (newsletter pair; front-end + synthetic test)
  (optional) s07-tag-group, s07-Intel, s07-AMD

YOUR EVENT DAY (UTC): 2025-05-11   (unique to you, so your alerts never mix with others)
