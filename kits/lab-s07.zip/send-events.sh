#!/bin/bash
# send-events.sh : sends one event per line of a file to the lab webhook (Mac and Linux)
# Usage, from this folder:  bash send-events.sh s07-scope-events.json
DIR="$(cd "$(dirname "$0")" && pwd)"
ENV="$DIR/lab.env"
[ -f "$ENV" ] && source "$ENV"
if [[ -z "$WEBHOOK_URL" || -z "$WEBHOOK_AUTH" || "$WEBHOOK_URL" == __* || "$WEBHOOK_AUTH" == __* ]]; then
  echo "First run: enter the webhook settings your instructor gave you (saved in lab.env)."
  read -r -p "Webhook URL: " WEBHOOK_URL
  read -r -p "Webhook user name: " WU
  read -r -s -p "Webhook password (hidden): " WP; echo
  WEBHOOK_AUTH="$WU:$WP"
  if [[ "$WEBHOOK_URL" != https://* || -z "$WU" || -z "$WP" ]]; then
    echo "Those settings look incomplete. Run the command again and copy them exactly."; exit 1
  fi
  umask 077
  printf '# Webhook settings for the lab (saved by send-events).\nWEBHOOK_URL=%q\nWEBHOOK_AUTH=%q\n' "$WEBHOOK_URL" "$WEBHOOK_AUTH" > "$ENV"
  chmod 600 "$ENV" 2>/dev/null
  echo "Saved. Sending now."
fi
if [ $# -eq 0 ]; then echo "Usage: bash send-events.sh <event-file>"; exit 1; fi
F="$1"; [ -f "$F" ] || F="$DIR/$1"
if [ ! -f "$F" ]; then echo "File not found: $1 (run this from your lab-s07 folder)"; exit 1; fi
case "$(basename "$F")" in s07-*) ;; *) echo "This kit belongs to s07. Only send files that start with s07-"; exit 1;; esac
count=0; fail=0
while IFS= read -r line || [ -n "$line" ]; do
  [ -z "${line//[[:space:]]/}" ] && continue
  code=$(curl -s -o /dev/null -w "%{http_code}" -X POST -u "$WEBHOOK_AUTH" --insecure \
         -H 'Content-Type: application/json' "$WEBHOOK_URL" --data-binary "$line")
  count=$((count+1))
  if [[ "$code" == 2* ]]; then echo "event $count sent, HTTP $code"; else echo "event $count FAILED, HTTP $code"; fail=$((fail+1)); fi
done < "$F"
if [ "$fail" -gt 0 ]; then
  echo "$fail of $count events failed."
  echo "HTTP 401 or 403: the webhook user name or password is wrong. Delete lab.env and run the same command again: it asks for the settings again."
  echo "HTTP 000: the webhook URL is wrong or not reachable from this network."
  exit 1
fi
echo "Done: $count events sent for s07"
