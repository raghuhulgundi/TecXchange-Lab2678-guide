=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s22
=====================================================================
Everything you create carries s22. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s22-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s22-application.txt               topology: billing + webserver on s22-computer1000
  s22-application2.txt              topology: notifications + email on s22-computer1001
  s22-topology-events-network.json  3 events: computer, router, firewall
  s22-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s22-topology-events-app.json      3 events: computer, billing, webserver
  s22-temporal-events.json          4 events: s22-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student22     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s22
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s22

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s22
  Observer job Unique IDs ......... s22-infrastructure
                                    s22-application
                                    s22-application2
  Merge rule name ................. s22-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s22-infrastructure.txt
                                    FILE.OBSERVER:s22-application.txt
  Exact template name ............. s22-router1        seed: s22-router1
  Dynamic template name ........... s22-AppServers     seed: s22-computer1000
  Dynamic template seed tag ....... LAB-s22
  Application name ................ s22-Order Capture Backend
  Application tag ................. s22-orderBackend
  Scope policy name ............... s22 - Group by Location-Application
  Temporal policies (search) ...... [s22]   (2 policies, created by the instructor's training)
  Scope policy application value .. s22-NetCash
  Optional tag template ........... s22-tag-template  group: s22-tag-group  tag: LAB-s22
  Optional token template ......... s22-token-template  provider: FILE.OBSERVER:s22-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s22-router1, APPSERVER-s22-computer1000, APPSERVER-s22-computer1001
  Temporal: 2 groups for s22-myapp (newsletter pair; front-end + synthetic test)
  (optional) s22-tag-group, s22-Intel, s22-AMD

YOUR EVENT DAY (UTC): 2025-05-26   (unique to you, so your alerts never mix with others)
