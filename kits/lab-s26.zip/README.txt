=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s26
=====================================================================
Everything you create carries s26. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s26-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s26-application.txt               topology: billing + webserver on s26-computer1000
  s26-application2.txt              topology: notifications + email on s26-computer1001
  s26-topology-events-network.json  3 events: computer, router, firewall
  s26-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s26-topology-events-app.json      3 events: computer, billing, webserver
  s26-temporal-events.json          4 events: s26-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student26     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s26
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s26

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s26
  Observer job Unique IDs ......... s26-infrastructure
                                    s26-application
                                    s26-application2
  Merge rule name ................. s26-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s26-infrastructure.txt
                                    FILE.OBSERVER:s26-application.txt
  Exact template name ............. s26-router1        seed: s26-router1
  Dynamic template name ........... s26-AppServers     seed: s26-computer1000
  Dynamic template seed tag ....... LAB-s26
  Application name ................ s26-Order Capture Backend
  Application tag ................. s26-orderBackend
  Scope policy name ............... s26 - Group by Location-Application
  Temporal policies (search) ...... [s26]   (2 policies, created by the instructor's training)
  Scope policy application value .. s26-NetCash
  Optional tag template ........... s26-tag-template  group: s26-tag-group  tag: LAB-s26
  Optional token template ......... s26-token-template  provider: FILE.OBSERVER:s26-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s26-router1, APPSERVER-s26-computer1000, APPSERVER-s26-computer1001
  Temporal: 2 groups for s26-myapp (newsletter pair; front-end + synthetic test)
  (optional) s26-tag-group, s26-Intel, s26-AMD

YOUR EVENT DAY (UTC): 2025-05-30   (unique to you, so your alerts never mix with others)
