# send-events.ps1 : sends one event per line of a file to the lab webhook (Windows 10 and 11)
# Usage, from this folder in PowerShell:  .\send-events.cmd s26-scope-events.json
param([Parameter(Mandatory=$true)][string]$File)
$ErrorActionPreference = 'Stop'
$envFile = Join-Path $PSScriptRoot 'lab.env'
$cfg = @{}
if (Test-Path $envFile) { Get-Content $envFile | Where-Object { $_ -match '^\s*([A-Z_]+)=(.*)$' } | ForEach-Object {
  $cfg[$Matches[1]] = $Matches[2].Trim().Trim('"').Trim("'")
} }
if (-not $cfg['WEBHOOK_URL'] -or -not $cfg['WEBHOOK_AUTH'] -or $cfg['WEBHOOK_URL'] -like '__*' -or $cfg['WEBHOOK_AUTH'] -like '__*') {
  Write-Host 'First run: enter the webhook settings your instructor gave you (saved in lab.env).'
  $url = (Read-Host 'Webhook URL').Trim()
  $user = (Read-Host 'Webhook user name').Trim()
  $sec = Read-Host 'Webhook password (hidden)' -AsSecureString
  $pw = (New-Object System.Net.NetworkCredential('', $sec)).Password
  if (-not $url.StartsWith('https://') -or -not $user -or -not $pw) { Write-Host 'Those settings look incomplete. Run the command again and copy them exactly.'; exit 1 }
  $cfg['WEBHOOK_URL'] = $url; $cfg['WEBHOOK_AUTH'] = "${user}:${pw}"
  $text = "# Webhook settings for the lab (saved by send-events).`nWEBHOOK_URL=`"$url`"`nWEBHOOK_AUTH=`"${user}:${pw}`"`n"
  [IO.File]::WriteAllText($envFile, $text, (New-Object Text.UTF8Encoding($false)))
  Write-Host 'Saved. Sending now.'
}
$path = $File
if (-not (Test-Path $path)) { $path = Join-Path $PSScriptRoot $File }
if (-not (Test-Path $path)) { Write-Host "File not found: $File (run this from your lab-s26 folder)"; exit 1 }
if ((Split-Path $path -Leaf) -notlike 's26-*') { Write-Host 'This kit belongs to s26. Only send files that start with s26-'; exit 1 }
$tmp = [IO.Path]::GetTempFileName()
$utf8 = New-Object Text.UTF8Encoding($false)
$n = 0; $fail = 0
foreach ($line in [IO.File]::ReadAllLines((Resolve-Path $path))) {
  if ($line.Trim() -eq '') { continue }
  [IO.File]::WriteAllText($tmp, $line, $utf8)
  $code = & curl.exe -s -o NUL -w '%{http_code}' -k -X POST -u $cfg['WEBHOOK_AUTH'] -H 'Content-Type: application/json' --data-binary "@$tmp" $cfg['WEBHOOK_URL']
  $n++
  if ("$code".StartsWith('2')) { Write-Host "event $n sent, HTTP $code" } else { Write-Host "event $n FAILED, HTTP $code"; $fail++ }
}
Remove-Item $tmp -ErrorAction SilentlyContinue
if ($fail -gt 0) {
  Write-Host "$fail of $n events failed."
  Write-Host 'HTTP 401 or 403: the webhook user name or password is wrong. Delete lab.env and run the same command again: it asks for the settings again.'
  Write-Host 'HTTP 000: the webhook URL is wrong or not reachable from this network.'
  exit 1
}
Write-Host "Done: $n events sent for s26"
