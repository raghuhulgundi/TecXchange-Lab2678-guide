=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s09
=====================================================================
Everything you create carries s09. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s09-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s09-application.txt               topology: billing + webserver on s09-computer1000
  s09-application2.txt              topology: notifications + email on s09-computer1001
  s09-topology-events-network.json  3 events: computer, router, firewall
  s09-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s09-topology-events-app.json      3 events: computer, billing, webserver
  s09-temporal-events.json          4 events: s09-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student09     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s09
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s09

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s09
  Observer job Unique IDs ......... s09-infrastructure
                                    s09-application
                                    s09-application2
  Merge rule name ................. s09-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s09-infrastructure.txt
                                    FILE.OBSERVER:s09-application.txt
  Exact template name ............. s09-router1        seed: s09-router1
  Dynamic template name ........... s09-AppServers     seed: s09-computer1000
  Dynamic template seed tag ....... LAB-s09
  Application name ................ s09-Order Capture Backend
  Application tag ................. s09-orderBackend
  Scope policy name ............... s09 - Group by Location-Application
  Temporal policies (search) ...... [s09]   (2 policies, created by the instructor's training)
  Scope policy application value .. s09-NetCash
  Optional tag template ........... s09-tag-template  group: s09-tag-group  tag: LAB-s09
  Optional token template ......... s09-token-template  provider: FILE.OBSERVER:s09-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s09-router1, APPSERVER-s09-computer1000, APPSERVER-s09-computer1001
  Temporal: 2 groups for s09-myapp (newsletter pair; front-end + synthetic test)
  (optional) s09-tag-group, s09-Intel, s09-AMD

YOUR EVENT DAY (UTC): 2025-05-13   (unique to you, so your alerts never mix with others)
