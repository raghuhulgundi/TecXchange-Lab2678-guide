=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s12
=====================================================================
Everything you create carries s12. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s12-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s12-application.txt               topology: billing + webserver on s12-computer1000
  s12-application2.txt              topology: notifications + email on s12-computer1001
  s12-topology-events-network.json  3 events: computer, router, firewall
  s12-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s12-topology-events-app.json      3 events: computer, billing, webserver
  s12-temporal-events.json          4 events: s12-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student12     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s12
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s12

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s12
  Observer job Unique IDs ......... s12-infrastructure
                                    s12-application
                                    s12-application2
  Merge rule name ................. s12-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s12-infrastructure.txt
                                    FILE.OBSERVER:s12-application.txt
  Exact template name ............. s12-router1        seed: s12-router1
  Dynamic template name ........... s12-AppServers     seed: s12-computer1000
  Dynamic template seed tag ....... LAB-s12
  Application name ................ s12-Order Capture Backend
  Application tag ................. s12-orderBackend
  Scope policy name ............... s12 - Group by Location-Application
  Temporal policies (search) ...... [s12]   (2 policies, created by the instructor's training)
  Scope policy application value .. s12-NetCash
  Optional tag template ........... s12-tag-template  group: s12-tag-group  tag: LAB-s12
  Optional token template ......... s12-token-template  provider: FILE.OBSERVER:s12-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s12-router1, APPSERVER-s12-computer1000, APPSERVER-s12-computer1001
  Temporal: 2 groups for s12-myapp (newsletter pair; front-end + synthetic test)
  (optional) s12-tag-group, s12-Intel, s12-AMD

YOUR EVENT DAY (UTC): 2025-05-16   (unique to you, so your alerts never mix with others)
