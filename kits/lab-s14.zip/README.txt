=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s14
=====================================================================
Everything you create carries s14. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s14-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s14-application.txt               topology: billing + webserver on s14-computer1000
  s14-application2.txt              topology: notifications + email on s14-computer1001
  s14-topology-events-network.json  3 events: computer, router, firewall
  s14-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s14-topology-events-app.json      3 events: computer, billing, webserver
  s14-temporal-events.json          4 events: s14-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student14     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s14
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s14

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s14
  Observer job Unique IDs ......... s14-infrastructure
                                    s14-application
                                    s14-application2
  Merge rule name ................. s14-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s14-infrastructure.txt
                                    FILE.OBSERVER:s14-application.txt
  Exact template name ............. s14-router1        seed: s14-router1
  Dynamic template name ........... s14-AppServers     seed: s14-computer1000
  Dynamic template seed tag ....... LAB-s14
  Application name ................ s14-Order Capture Backend
  Application tag ................. s14-orderBackend
  Scope policy name ............... s14 - Group by Location-Application
  Temporal policies (search) ...... [s14]   (2 policies, created by the instructor's training)
  Scope policy application value .. s14-NetCash
  Optional tag template ........... s14-tag-template  group: s14-tag-group  tag: LAB-s14
  Optional token template ......... s14-token-template  provider: FILE.OBSERVER:s14-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s14-router1, APPSERVER-s14-computer1000, APPSERVER-s14-computer1001
  Temporal: 2 groups for s14-myapp (newsletter pair; front-end + synthetic test)
  (optional) s14-tag-group, s14-Intel, s14-AMD

YOUR EVENT DAY (UTC): 2025-05-18   (unique to you, so your alerts never mix with others)
