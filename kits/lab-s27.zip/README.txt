=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s27
=====================================================================
Everything you create carries s27. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s27-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s27-application.txt               topology: billing + webserver on s27-computer1000
  s27-application2.txt              topology: notifications + email on s27-computer1001
  s27-topology-events-network.json  3 events: computer, router, firewall
  s27-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s27-topology-events-app.json      3 events: computer, billing, webserver
  s27-temporal-events.json          4 events: s27-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student27     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s27
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s27

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s27
  Observer job Unique IDs ......... s27-infrastructure
                                    s27-application
                                    s27-application2
  Merge rule name ................. s27-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s27-infrastructure.txt
                                    FILE.OBSERVER:s27-application.txt
  Exact template name ............. s27-router1        seed: s27-router1
  Dynamic template name ........... s27-AppServers     seed: s27-computer1000
  Dynamic template seed tag ....... LAB-s27
  Application name ................ s27-Order Capture Backend
  Application tag ................. s27-orderBackend
  Scope policy name ............... s27 - Group by Location-Application
  Temporal policies (search) ...... [s27]   (2 policies, created by the instructor's training)
  Scope policy application value .. s27-NetCash
  Optional tag template ........... s27-tag-template  group: s27-tag-group  tag: LAB-s27
  Optional token template ......... s27-token-template  provider: FILE.OBSERVER:s27-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s27-router1, APPSERVER-s27-computer1000, APPSERVER-s27-computer1001
  Temporal: 2 groups for s27-myapp (newsletter pair; front-end + synthetic test)
  (optional) s27-tag-group, s27-Intel, s27-AMD

YOUR EVENT DAY (UTC): 2025-05-31   (unique to you, so your alerts never mix with others)
