@powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0send-events.ps1" %*
