=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s10
=====================================================================
Everything you create carries s10. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s10-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s10-application.txt               topology: billing + webserver on s10-computer1000
  s10-application2.txt              topology: notifications + email on s10-computer1001
  s10-topology-events-network.json  3 events: computer, router, firewall
  s10-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s10-topology-events-app.json      3 events: computer, billing, webserver
  s10-temporal-events.json          4 events: s10-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student10     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s10
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s10

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s10
  Observer job Unique IDs ......... s10-infrastructure
                                    s10-application
                                    s10-application2
  Merge rule name ................. s10-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s10-infrastructure.txt
                                    FILE.OBSERVER:s10-application.txt
  Exact template name ............. s10-router1        seed: s10-router1
  Dynamic template name ........... s10-AppServers     seed: s10-computer1000
  Dynamic template seed tag ....... LAB-s10
  Application name ................ s10-Order Capture Backend
  Application tag ................. s10-orderBackend
  Scope policy name ............... s10 - Group by Location-Application
  Temporal policies (search) ...... [s10]   (2 policies, created by the instructor's training)
  Scope policy application value .. s10-NetCash
  Optional tag template ........... s10-tag-template  group: s10-tag-group  tag: LAB-s10
  Optional token template ......... s10-token-template  provider: FILE.OBSERVER:s10-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s10-router1, APPSERVER-s10-computer1000, APPSERVER-s10-computer1001
  Temporal: 2 groups for s10-myapp (newsletter pair; front-end + synthetic test)
  (optional) s10-tag-group, s10-Intel, s10-AMD

YOUR EVENT DAY (UTC): 2025-05-14   (unique to you, so your alerts never mix with others)
