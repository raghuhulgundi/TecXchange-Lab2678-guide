=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s16
=====================================================================
Everything you create carries s16. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s16-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s16-application.txt               topology: billing + webserver on s16-computer1000
  s16-application2.txt              topology: notifications + email on s16-computer1001
  s16-topology-events-network.json  3 events: computer, router, firewall
  s16-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s16-topology-events-app.json      3 events: computer, billing, webserver
  s16-temporal-events.json          4 events: s16-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student16     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s16
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s16

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s16
  Observer job Unique IDs ......... s16-infrastructure
                                    s16-application
                                    s16-application2
  Merge rule name ................. s16-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s16-infrastructure.txt
                                    FILE.OBSERVER:s16-application.txt
  Exact template name ............. s16-router1        seed: s16-router1
  Dynamic template name ........... s16-AppServers     seed: s16-computer1000
  Dynamic template seed tag ....... LAB-s16
  Application name ................ s16-Order Capture Backend
  Application tag ................. s16-orderBackend
  Scope policy name ............... s16 - Group by Location-Application
  Temporal policies (search) ...... [s16]   (2 policies, created by the instructor's training)
  Scope policy application value .. s16-NetCash
  Optional tag template ........... s16-tag-template  group: s16-tag-group  tag: LAB-s16
  Optional token template ......... s16-token-template  provider: FILE.OBSERVER:s16-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s16-router1, APPSERVER-s16-computer1000, APPSERVER-s16-computer1001
  Temporal: 2 groups for s16-myapp (newsletter pair; front-end + synthetic test)
  (optional) s16-tag-group, s16-Intel, s16-AMD

YOUR EVENT DAY (UTC): 2025-05-20   (unique to you, so your alerts never mix with others)
