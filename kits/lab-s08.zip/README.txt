=====================================================================
  LAB-2678 STUDENT KIT          YOUR STUDENT ID:  s08
=====================================================================
Everything you create carries s08. Never edit, disable, clear or
delete anything that does not carry YOUR id. Copy names from this
sheet exactly (they are case sensitive).

FILES IN THIS FOLDER
  s08-infrastructure.txt            topology: router, firewall, CPUs, computer, person
  s08-application.txt               topology: billing + webserver on s08-computer1000
  s08-application2.txt              topology: notifications + email on s08-computer1001
  s08-topology-events-network.json  3 events: computer, router, firewall
  s08-scope-events.json             8 events: DB2, Liberty, API in 3 regions
  s08-topology-events-app.json      3 events: computer, billing, webserver
  s08-temporal-events.json          4 events: s08-myapp newsletter, front-end, synthetic test
  send-events.sh                      sends an event file (Mac, Linux)
  send-events.cmd, send-events.ps1    sends an event file (Windows)
  lab.env                             webhook settings, asked for the first time you send

LOG IN TO CONCERT OPERATE (browser)
  Concert Operate URL: from your instructor
  Login method: Enterprise LDAP     user: student08     password: from your instructor

OPEN A TERMINAL IN THIS FOLDER
  Mac:     Terminal, then:     cd ~/Downloads/lab-s08
  Windows: PowerShell, then:   cd $HOME\Downloads\lab-s08

SEND EVENTS (from this folder)
  Mac / Linux:  bash send-events.sh <file>
  Windows:      .\send-events.cmd <file>
  The first time, it asks for the webhook URL, user name and password
  your instructor gave you, and saves them in lab.env on your laptop.

NAMES YOU WILL TYPE
  Alert search keyword ............ s08
  Observer job Unique IDs ......... s08-infrastructure
                                    s08-application
                                    s08-application2
  Merge rule name ................. s08-InfraApps
  Merge rule providers ............ FILE.OBSERVER:s08-infrastructure.txt
                                    FILE.OBSERVER:s08-application.txt
  Exact template name ............. s08-router1        seed: s08-router1
  Dynamic template name ........... s08-AppServers     seed: s08-computer1000
  Dynamic template seed tag ....... LAB-s08
  Application name ................ s08-Order Capture Backend
  Application tag ................. s08-orderBackend
  Scope policy name ............... s08 - Group by Location-Application
  Temporal policies (search) ...... [s08]   (2 policies, created by the instructor's training)
  Scope policy application value .. s08-NetCash
  Optional tag template ........... s08-tag-template  group: s08-tag-group  tag: LAB-s08
  Optional token template ......... s08-token-template  provider: FILE.OBSERVER:s08-infrastructure.txt

GROUPS YOU SHOULD SEE
  ROUTER-s08-router1, APPSERVER-s08-computer1000, APPSERVER-s08-computer1001
  Temporal: 2 groups for s08-myapp (newsletter pair; front-end + synthetic test)
  (optional) s08-tag-group, s08-Intel, s08-AMD

YOUR EVENT DAY (UTC): 2025-05-12   (unique to you, so your alerts never mix with others)
